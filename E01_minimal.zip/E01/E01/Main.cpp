#include "Main.h"

using namespace std;

int main() 
{
	cout << "Hello World!\n";

	cout << "Press enter to continue";
	getchar();
	return 0;
}